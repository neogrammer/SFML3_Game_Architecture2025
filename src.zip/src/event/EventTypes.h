#pragma once

//enum class EventType
//{
//	StartedMoving,
//	StoppedMoving,
//	StartedShooting,
//	StoppedShooting,
//	Landing,
//	Landed,
//	Dashing,
//	StartedJumping,
//	Rising,
//	Falling,
//	TakingDamage,
//	NONE = 10,
//};
//
//static EventType EventAnimLUT(const std::string& eventName) {
//	EventType type = EventType::NONE;
//
//	if (eventName == "StoppedMoving")
//	{
//		type = EventType::NONE;
//
//	}
//};