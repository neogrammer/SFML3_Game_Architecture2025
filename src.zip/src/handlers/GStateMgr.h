#pragma once
#include <SFML/Graphics.hpp>

class GStateMgr
{
	sf::RenderWindow* pWnd;
	sf::Time* pGameTime;

public:
	GStateMgr(sf::RenderWindow& wnd_, sf::Time& gameTime_) : pWnd{ &wnd_ }, pGameTime{ &gameTime_ } {}

	~GStateMgr() {}
	GStateMgr(const GStateMgr&) = delete;
	GStateMgr& operator=(const GStateMgr&) = delete;

	void processEvents();
	void runScripts();
	void handleStaticInput();
	void updateGame();
	void handleCollisions();
	void finalizeState();
	void renderScene();
	void tickSimulation();

};