#include <handlers/GStateMgr.h>

void GStateMgr::processEvents()
{
}

void GStateMgr::runScripts()
{
}

void GStateMgr::handleStaticInput()
{
}

void GStateMgr::updateGame()
{
}

void GStateMgr::handleCollisions()
{
}

void GStateMgr::finalizeState()
{
}

void GStateMgr::renderScene()
{
}

void GStateMgr::tickSimulation()
{
}
