#pragma once

constexpr unsigned int gWndWidth = 1600U;
constexpr unsigned int gWndHeight = 900U;
