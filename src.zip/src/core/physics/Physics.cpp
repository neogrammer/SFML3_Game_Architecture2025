#include "Physics.h"

float Physics::Gravity = 1600.f;