#pragma once
#include <SFML/Graphics.hpp>
#include <global.h>
#include <handlers/GStateMgr.h>
#include <optional>


class AGameApp
{
	sf::RenderWindow mWnd;
	bool mGameOver;

	sf::Time mGameTime;

	GStateMgr stateMgr;

    std::string processEvents();
	void runScripts();
	void handleStaticInput();
	void updateGame();
	void handleCollisions();
	void finalizeState();
	void renderScene();
	void tickSimulation();



public:
	AGameApp();
	~AGameApp();
	AGameApp(const AGameApp&) = delete;
	AGameApp& operator=(const AGameApp&) = delete;


	void run();


};