//AGameApp.cpp
#include <core/app/AGameApp.h>
#include <err/ErrorMacros.h>

AGameApp::AGameApp() : mWnd{ sf::VideoMode{{gWndWidth,gWndHeight}, 32U }, "Xastle Xashers", sf::State::Windowed }, mGameOver{ false }, mGameTime{ sf::Time::Zero }, stateMgr{ mWnd,mGameTime } {}
AGameApp::~AGameApp() {}

void AGameApp::run()
{
	sf::Clock frameClock = {};
	sf::Time frameTime = sf::Time::Zero;

	/// GameStateMgr create

	if (!mWnd.isOpen())
	{
		mGameOver = true;
	}

	while (!mGameOver)
	{


		// only changes state flags, does not move any positions
		if (!mGameOver)
		{
			
			chk(processEvents());
			handleStaticInput();
			runScripts();
		}


		if (!mGameOver)
		{
			updateGame();
			handleCollisions();
			tickSimulation();
		}

		if (!mGameOver)
		{
			finalizeState();
			renderScene();
		}


	}

	if (mWnd.isOpen())
		mWnd.close();


}

std::string AGameApp::processEvents()
{

	while (const std::optional event = mWnd.pollEvent())
	{
		if (event->is<sf::Event::Closed>())
		{
			mGameOver = true;
			mWnd.close();

		}
		if (event->is<sf::Event::KeyReleased>()) 
		{
			const auto* keyReleased = event->getIf<sf::Event::KeyReleased>();
			if (!keyReleased) break;

			if (keyReleased->scancode == sf::Keyboard::Scancode::Escape) 
			{
				mGameOver = true;
			}
		}
	}
	return "OK";
}

void AGameApp::runScripts()
{
}

void AGameApp::handleStaticInput()
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Escape))
	{
		mGameOver = true;
	}
}

void AGameApp::updateGame()
{
	// stateMgr.updateStateStack();
}

void AGameApp::handleCollisions()
{
}

void AGameApp::finalizeState()
{
}

void AGameApp::tickSimulation()
{
}


void AGameApp::renderScene()
{
	mWnd.clear(sf::Color(46, 146, 246, 255));

	mWnd.display();
}

