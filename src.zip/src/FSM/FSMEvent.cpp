#include <FSM/FSMEvent.h>

FSMEvent::~FSMEvent() {}