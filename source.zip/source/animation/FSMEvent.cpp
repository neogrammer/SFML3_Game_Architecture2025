#include "FSMEvent.h"

FSMEvent::~FSMEvent() {}